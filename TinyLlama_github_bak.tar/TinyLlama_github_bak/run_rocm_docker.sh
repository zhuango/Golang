#!/bin/bash

HERE=$(pwd -P) # Absolute path of current directory
user=$(whoami)
uid=$(id -u)
gid=$(id -g)

sudo docker run \
  -v /dev/shm:/dev/shm\
  -v /home/amd:/home/amd \
  -v /mnt/data:/mnt/data \
  -e USER=$user -e UID=$uid -e GID=$gid \
  -v $HERE:/mnt/data/TinyLlama_github\
  -w /mnt/data/TinyLlama_github \
  --device=/dev/kfd \
  --device=/dev/dri \
  --security-opt \
  seccomp=unconfined \
  --group-add video \
  -it \
  --rm \
  --network=host \
  dc634ab7b3ed
  # 19c0b189e56a  
  # 9278fa37bf56
  # llama_pretrain:with_flash_attn_torch_2.0.1
  # llama_pretrain:with_flash_attn
  # 542a1b97718d
