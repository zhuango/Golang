#export DATA_PATH=./slim_star_combined
export DATA_PATH=./slim_star_combined
export CUDA_VISIBLE_DEVICES="4,7"

lightning run model \
    --node-rank=0  \
    --main-address=localhost \
    --accelerator=cuda \
    --devices=2 \
    --num-nodes=1 \
    --main-port=22221 \
    pretrain/tinyllama.py --precision 'bf16-mixed' --devices 2 --train_data_dir $DATA_PATH  --val_data_dir $DATA_PATH
