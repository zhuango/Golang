sudo cp daemon.json /etc/docker/daemon.json
sudo service docker restart

