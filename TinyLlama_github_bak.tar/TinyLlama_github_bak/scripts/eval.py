import os
import glob
import math
import sys
import time
from pathlib import Path
from typing import Optional, Tuple, Union
import math
import lightning as L
import torch
from lightning.fabric.strategies import FSDPStrategy, XLAStrategy, DDPStrategy
from torch.utils.data import DataLoader
from functools import partial
# support running without installing as a package
wd = Path(__file__).parent.parent.resolve()
sys.path.append(str(wd))
# from apex.optimizers import FusedAdam #torch optimizer has a cuda backend, which is faster actually
from lit_gpt.model import GPT
from lit_gpt.model import Block, Config, CausalSelfAttention
from lit_gpt.packed_dataset import CombinedDataset, PackedDataset
from lit_gpt.speed_monitor import SpeedMonitorFabric as Monitor
from lit_gpt.speed_monitor import estimate_flops, measure_flops
from lit_gpt.utils import chunked_cross_entropy, get_default_supported_precision, num_parameters, step_csv_logger, lazy_load
from pytorch_lightning.loggers import WandbLogger
#from lit_gpt import FusedCrossEntropyLoss
import random

from mup import MuReadout, make_base_shapes, set_base_shapes, MuSGD, MuAdam, MuAdamW

### model_name = "tiny_LLaMA_new41M"
model_name = 'tiny_LLaMA_450M' # model to train
base_model_name = "tiny_LLaMA_base"  # smallest model
delta_model_name = "tiny_LLaMA_delta" # a model vary from base model, just for initialization

# model_name = "tiny_LLaMA_base"
# base_model_name = "tiny_LLaMA_base"
# delta_model_name = "tiny_LLaMA_110M"
name = "tinyllama"
out_dir = Path("out_bak") / (name+"_mup_450M")

# Hyperparameters
num_node=1
num_of_devices = 1
global_batch_size = 4

# learning_rate = 4e-4
micro_batch_size = 2
# max_step = 715256 * 2
max_step = int(985.59 * 10**9/(1024*4096))
warmup_steps = 2000
log_step_interval = 100
eval_iters = 100
save_step_interval = 10000
eval_step_interval = 10000


weight_decay = 1e-1
beta1 = 0.9
beta2 = 0.95
grad_clip = 1.0
decay_lr = True
# min_lr = 4e-5

batch_size = global_batch_size // num_of_devices
gradient_accumulation_steps = batch_size // micro_batch_size
assert gradient_accumulation_steps > 0
warmup_iters = warmup_steps * gradient_accumulation_steps




max_iters = max_step * gradient_accumulation_steps
lr_decay_iters = max_iters
log_iter_interval = int(log_step_interval * gradient_accumulation_steps)


# Treat all dataset equally by their size. If you want to use a different weight for a dataset, add it to the list with the weight.
# train_data_config = [
#     ("train_slim", 1.0),
#     #("train_star", 0.306416),
# ]
train_data_config = [
    ("train_slim", 1.0),
]

val_data_config = [
    ("test_wikitext", 1.0),
]

hparams = {k: v for k, v in locals().items() if isinstance(v, (int, float, str)) and not k.startswith("_")}
logger = step_csv_logger("out", name, flush_logs_every_n_steps=log_iter_interval)
wandb_logger = WandbLogger()


def setup(
    devices: int = 1,
    train_data_dir: Path = Path("./slim_star_combined"),
    val_data_dir: Optional[Path] = None,
    precision: Optional[str] = 'bf16-mixed',
    tpu: bool = False,
    resume: Union[bool, Path] = False,
    learning_rate: float = 5e-4,
    lr_schedule: str = "cosine",
    initializer_range: float = 0.02, 
    optimizer: str = 'AdamW'
) -> None:
    precision = precision or get_default_supported_precision(training=True, tpu=tpu)

    if devices > 1:
        if tpu:
            # For multi-host TPU training, the device count for Fabric is limited to the count on a single host.
            devices = "auto"
            strategy = XLAStrategy(sync_module_states=False)
        else:
            # strategy = FSDPStrategy(
            #     auto_wrap_policy={Block},
            #     activation_checkpointing_policy=None,
            #     state_dict_type="full",
            #     limit_all_gathers=True,
            #     cpu_offload=False,
            # )
            strategy = DDPStrategy()  ## mup, mup do not support FSDP, use DDP instead
    else:
        strategy = "auto"

    fabric = L.Fabric(devices=devices, strategy=strategy, precision=precision, loggers=[logger, wandb_logger])
    fabric.print(hparams)
    #fabric.launch(main, train_data_dir, val_data_dir, resume)
    main(fabric, train_data_dir, val_data_dir, resume, learning_rate, lr_schedule, initializer_range, optimizer)


## mup, adjustable parameters are passed into the main function
def main(fabric, train_data_dir, val_data_dir, resume, learning_rate, lr_schedule, initializer_range, optimizer='AdamW'):
    monitor = Monitor(fabric, window_size=2, time_unit="seconds", log_iter_interval=log_iter_interval)

    if fabric.global_rank == 0:
        out_dir.mkdir(parents=True, exist_ok=True)

    config = Config.from_name(model_name)
    base_config = Config.from_name(base_model_name)
    delta_config = Config.from_name(delta_model_name)

    train_dataloader, val_dataloader = create_dataloaders(
        batch_size=micro_batch_size,
        block_size=config.block_size,
        fabric=fabric,
        train_data_dir=train_data_dir,
        val_data_dir=val_data_dir,
        seed=3407,
    )
    if val_dataloader is None:
        train_dataloader = fabric.setup_dataloaders(train_dataloader)
    else:
        train_dataloader, val_dataloader = fabric.setup_dataloaders(train_dataloader, val_dataloader)

    fabric.seed_everything(3407)  # same seed for every process to init model (FSDP)

    fabric.print(f"Loading model with {config.__dict__}")
    t0 = time.perf_counter()
    with fabric.init_module(empty_init=False):
        model = GPT(config)

        base_model = GPT(base_config)
        delta_model = GPT(delta_config)
        print("====================setting base shapes==================")
        set_base_shapes(model, base_model, delta=delta_model)

        model.apply(partial(model._init_weights ,n_layer=config.n_layer, initializer_range=initializer_range))
 

    fabric.print(f"Time to instantiate model: {time.perf_counter() - t0:.02f} seconds.")
    fabric.print(f"Total parameters {num_parameters(model):,}")

    model = fabric.setup(model)
    # optimizer = torch.optim.AdamW(
    #     model.parameters(), lr=learning_rate, weight_decay=weight_decay, betas=(beta1, beta2), foreach=False
    # )
    if optimizer == 'AdamW':
        optimizer = MuAdamW(
            model.parameters(), lr=learning_rate, weight_decay=weight_decay, betas=(beta1, beta2), foreach=False
        )
    else:
        optimizer = MuSGD(model.parameters(), lr=learning_rate, momentum=0.9, weight_decay=weight_decay)
    # optimizer = FusedAdam(model.parameters(), lr=learning_rate, weight_decay=weight_decay, betas=(beta1, beta2),adam_w_mode=True)
    optimizer = fabric.setup_optimizers(optimizer)

    state = {"model": model, "optimizer": optimizer, "hparams": hparams, "iter_num": 0, "step_count": 0}

    # if resume is True:
    resume = sorted(out_dir.glob("*.pth"))[-1]
    # if resume :
    #     fabric.print(f"Resuming training from {resume}")
    
    print(resume, state)
    fabric.load(resume, state)

    train_time = time.perf_counter()
    train(fabric, state, train_dataloader, val_dataloader, monitor, resume, learning_rate, lr_schedule)
    fabric.print(f"Training time: {(time.perf_counter()-train_time):.2f}s")
    if fabric.device.type == "cuda":
        fabric.print(f"Memory used: {torch.cuda.max_memory_allocated() / 1e9:.02f} GB")


def train(fabric, state, train_dataloader, val_dataloader, monitor, resume, learning_rate, lr_schedule):
    model = state["model"]
    optimizer = state["optimizer"]

    # if val_dataloader is not None:
    #     validate(fabric, model, val_dataloader)  # sanity check
    
    val_loss = validate(fabric, model, val_dataloader)

global_model = None
        
@torch.no_grad()
def validate(fabric: L.Fabric, model: torch.nn.Module, val_dataloader: DataLoader) -> torch.Tensor:
    fabric.print("Validating ...")
    
    model_name = 'tiny_LLaMA_450M' # model to train
    base_model_name = "tiny_LLaMA_base"  # smallest model
    delta_model_name = "tiny_LLaMA_delta" # a model vary from base model, just for initialization
    config = Config.from_name(model_name)
    base_config = Config.from_name(base_model_name)
    delta_config = Config.from_name(delta_model_name)
    from transformers import AutoModelForCausalLM, AutoTokenizer
    """
    lm_model = AutoModelForCausalLM.from_pretrained('out_bak_iter_460000')
    lm_model_base = AutoModelForCausalLM.from_pretrained('tiny_llama_base')
    lm_model_delta = AutoModelForCausalLM.from_pretrained('tiny_llama_delta')

    set_base_shapes(lm_model, lm_model_base, delta=lm_model_delta)
    lm_model.apply(partial(model._init_weights ,n_layer=config.n_layer, initializer_range=0.02))
    w = torch.load('out_bak_iter_460000/pytorch_model.bin')
    lm_model.load_state_dict(w)
    model = lm_model.cuda()
    """
    #model = AutoModelForCausalLM.from_pretrained('../TinyLlama-1.1B-intermediate-step-480k-1T/').cuda()

    #"""
    model = GPT(config)
    base_model = GPT(base_config)
    delta_model = GPT(delta_config)
    set_base_shapes(model, base_model, delta=delta_model)
    model.apply(partial(model._init_weights ,n_layer=config.n_layer, initializer_range=0.02))
    w = torch.load('./out/tinyllama_mup_450M/iter-460000-ckpt.pth', map_location=torch.device('cpu'))
    model.load_state_dict(w['model'])
    model.cuda()
    #"""
    if global_model != None:
        print('setting global model')
        model = global_model
    model.eval()

    losses = torch.zeros(eval_iters, device=fabric.device)
    for k, val_data in enumerate(val_dataloader):
        if k >= eval_iters:
            break
        input_ids = val_data[:, 0 : 4096].contiguous()
        targets = val_data[:, 1 : 4096 + 1].contiguous()
        if input_ids[0, -1] == 1:
            break
        # logits = model(input_ids)['logits']
        logits = model(input_ids)#['logits']
        loss = chunked_cross_entropy(logits, targets, chunk_size=0)

        # loss_func = FusedCrossEntropyLoss()
        # loss = loss_func(logits, targets)
        losses[k] = loss.item()
        print('kkkkkkkkkkkkkkk: ', k)
    out = losses[0:k].mean()
    print(out)

    model.train()
    return out


def create_dataloader(
    batch_size: int, block_size: int, data_dir: Path, fabric, shuffle: bool = True, seed: int = 12345, split="train"
) -> DataLoader:
    datasets = []
    data_config = train_data_config if split == "train" else val_data_config
    for prefix, _ in data_config:
        filenames = sorted(glob.glob(str(data_dir / f"{prefix}*")))
        random.seed(seed)
        random.shuffle(filenames)
        dataset = PackedDataset(
            filenames,
            # n_chunks control the buffer size. 
            # Note that the buffer size also impacts the random shuffle
            # (PackedDataset is an IterableDataset. So the shuffle is done by prefetch a buffer and shuffle the buffer)
            n_chunks=8,
            block_size=block_size,
            shuffle=shuffle,
            seed=seed+fabric.global_rank,
            num_processes=fabric.world_size,
            process_rank=fabric.global_rank,
        )
        datasets.append(dataset)

    if not datasets:
        raise RuntimeError(
            f"No data found at {data_dir}. Make sure you ran prepare_redpajama.py to create the dataset."
        )

    weights = [weight for _, weight in data_config]
    sum_weights = sum(weights)
    weights = [el / sum_weights for el in weights]

    combined_dataset = CombinedDataset(datasets=datasets, seed=seed, weights=weights)

    return DataLoader(combined_dataset, batch_size=1, shuffle=False, pin_memory=True)


def create_dataloaders(
    batch_size: int,
    block_size: int,
    fabric,
    train_data_dir: Path = Path("data/redpajama_sample"),
    val_data_dir: Optional[Path] = None,
    seed: int = 12345,
) -> Tuple[DataLoader, DataLoader]:
    # Increase by one because we need the next word as well
    effective_block_size = block_size + 1
    train_dataloader = create_dataloader(
        batch_size=batch_size,
        block_size=effective_block_size,
        fabric=fabric,
        data_dir=train_data_dir,
        shuffle=True,
        seed=seed,
        split="train"
    )
    print(val_data_dir, 'ddddddddddd')
    val_dataloader = (
        create_dataloader(
            batch_size=batch_size,
            block_size=effective_block_size,
            fabric=fabric,
            data_dir=val_data_dir,
            shuffle=False,
            seed=seed,
            split="validation"
        )
        if val_data_dir
        else None
    )
    return train_dataloader, val_dataloader


# learning rate decay scheduler (cosine with warmup)
### mup, add linear learning rate
def get_lr(it, init_lr=4e-5, min_lr_ratio=0.1, schedule="cosine"):
    # 1) linear warmup for warmup_iters steps
    learning_rate = init_lr 
    min_lr = min_lr_ratio * learning_rate
    if it < warmup_iters:
        return learning_rate * it / warmup_iters
    # 2) if it > lr_decay_iters, return min learning rate
    if it > lr_decay_iters:
        return min_lr
    # 3) in between, use cosine decay down to min learning rate
    decay_ratio = (it - warmup_iters) / (lr_decay_iters - warmup_iters)
    assert 0 <= decay_ratio <= 1
    if schedule == 'cosine':
        coeff = 0.5 * (1.0 + math.cos(math.pi * decay_ratio))  # coeff ranges 0..1
    elif schedule == 'linear':
        coeff = 1.0 - decay_ratio
    return min_lr + coeff * (learning_rate - min_lr)


if __name__ == "__main__":
    # Uncomment this line if you see an error: "Expected is_sm80 to be true, but got false"
    # torch.backends.cuda.enable_flash_sdp(False)
    torch.set_float32_matmul_precision("high")

    from jsonargparse import CLI

    CLI(setup)
