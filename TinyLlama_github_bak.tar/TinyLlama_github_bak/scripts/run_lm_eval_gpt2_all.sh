#!/bin/bash

# 设置环境变量
export HF_DATASETS_CACHE="./huggingface_data"

# 定义模型列表
models="gpt2 gpt2-large gpt2-medium gpt2-xl"

# 定义任务列表
tasks="winogrande,piqa,sciq,wsc,arc_easy,arc_challenge,logiqa,mmlu,hellaswag"

# 循环评估不同的模型
for model in $models; do
	for cuda_device in $(seq 2 5); do
        export CUDA_VISIBLE_DEVICES="$cuda_device"
        
        echo "Evaluating model $model on CUDA device $cuda_device"
        
        lm_eval --model hf \
            --model_args pretrained=../$model \
            --tasks $tasks \
            --device cuda:0 \
            --batch_size 1 &  # 后台运行，启动多个进程
        
        echo "Finished evaluating $model on CUDA device $cuda_device"
    done
done

# 等待所有后台进程完成
wait

echo "Script completed"

