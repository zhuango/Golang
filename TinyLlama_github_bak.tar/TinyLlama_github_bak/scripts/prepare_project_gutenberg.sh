#xcdlgpu03:/scratch1_nvme_1/workspace/project_gutenberg
# source_path=/scratch1_nvme_1/workspace/project_gutenberg
# target_path=/scratch1_nvme_2/workspace/slim_star_gutenberg_openwebmath_combined
# target_path=/scratch1_nvme_2/workspace/project_gutenberg_test

source_path=/mnt/data/llm_datasets/project_gutenberg
target_path=/mnt/data/llm_datasets/project_gutenberg_processed

# train: 873 secs, ~20G
tokenizer_path=./tokenizer

python prepare_project_gutenberg.py \
    --source_path $source_path \
    --tokenizer_path $tokenizer_path  \
    --destination_path $target_path \
    --split train \
    --percentage 1.0
