#xcdlgpu03:/scratch1_nvme_1/workspace/SlimPajama-627B
source_path=/mnt/data/wikitext-2-raw/
# target_path=/scratch1_nvme_2/workspace/slim_star_gutenberg_openwebmath_combined
target_path=/mnt/data/wikitext2-raw_processed
#train: 26403 secs, 1.2T
tokenizer_path=./tokenizer

python prepare_wikitext.py \
    --source_path $source_path \
    --tokenizer_path $tokenizer_path  \
    --destination_path $target_path \
    --split test \
    --percentage 1.0

