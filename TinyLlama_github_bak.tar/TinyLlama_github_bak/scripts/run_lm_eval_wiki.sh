export HF_DATASETS_CACHE="./huggingface_data"
export PYTHONPATH=$PYTHONPATH:./
# cp ./modeling_llama_mup.py /opt/conda/envs/py_3.10/lib/python3.10/site-packages/transformers/models/llama/modeling_llama.py
cp ./evaluator_origin.py /opt/conda/envs/py_3.10/lib/python3.10/site-packages/lm_eval/evaluator.py 
# cp lm_eval_huggingface.py /opt/conda/envs/py_3.10/lib/python3.10/site-packages/lm_eval/models/huggingface.py 
# cp lm_eval_utils.py /opt/conda/envs/py_3.10/lib/python3.10/site-packages/lm_eval/utils.py 
# cp lm_eval_utils_origin.py /opt/conda/envs/py_3.10/lib/python3.10/site-packages/lm_eval/utils.py 

iter='020000'
# for task in lambada_openai arc_easy arc_challenge logiqa hellaswag mmlu  
#for task in lambada_openai winogrande piqa sciq wsc arc_easy arc_challenge logiqa hellaswag mmlu  
	#lambada_openai winogrande piqa sciq wsc arc_easy arc_challenge logiqa hellaswag mmlu  
#for task in lambada_openai
for task in wikitext
do
    export CUDA_VISIBLE_DEVICES="1"
    lm_eval --model hf \
        --model_args pretrained=./out_bak_450m_iter_${iter}\
        --tasks $task \
        --device cuda:0 \
        --batch_size 1 
done
    # winogrande,piqa,sciq,wsc,mmlu,lambada_openai,wikitext \
    # --tasks winogrande,piqa,sciq,wsc,mmlu,hellaswag,openbookqa,lambada_openai \
