iter=020000
model_path=./out_bak_450m_iter_$iter/
mkdir $model_path
checkpoint_name=iter-${iter}-ckpt.pth
# cp ./out/tinyllama_mup_450M/$checkpoint_name $model_path
cp /mnt/data/amd/out/tinyllama_450M_2024_01_09/$checkpoint_name $model_path
python scripts/convert_lit_checkpoint.py \
    --checkpoint_name=$checkpoint_name\
    --out_dir=$model_path \
    --model_name='tiny_LLaMA_450M' \
    --model_only=False

cp ./scripts/tokenizer/* ${model_path}
mv ${model_path}/iter-${iter}-ckpt.bin ${model_path}/pytorch_model.bin
rm ${model_path}/${checkpoint_name}
