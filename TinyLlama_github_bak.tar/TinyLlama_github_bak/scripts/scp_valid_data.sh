scp -r -i /home/amd/id_rsa /mnt/data/llm_datasets/slim_validation_processed root@10.216.114.122:/mnt/data/llm_datasets/
scp -r -i /home/amd/id_rsa /mnt/data/llm_datasets/slim_validation_processed root@10.216.114.129:/mnt/data/llm_datasets/
scp -r -i /home/amd/id_rsa /mnt/data/llm_datasets/slim_validation_processed root@10.216.114.130:/mnt/data/llm_datasets/
scp -r -i /home/amd/id_rsa /mnt/data/llm_datasets/slim_validation_processed root@10.216.114.131:/mnt/data/llm_datasets/
scp -r -i /home/amd/id_rsa /mnt/data/llm_datasets/slim_validation_processed root@10.216.114.132:/mnt/data/llm_datasets/
scp -r -i /home/amd/id_rsa /mnt/data/llm_datasets/slim_validation_processed root@10.216.114.133:/mnt/data/llm_datasets/
scp -r -i /home/amd/id_rsa /mnt/data/llm_datasets/slim_validation_processed root@10.216.114.134:/mnt/data/llm_datasets/
