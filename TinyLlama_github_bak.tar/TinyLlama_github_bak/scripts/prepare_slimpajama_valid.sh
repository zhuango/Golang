#xcdlgpu03:/scratch1_nvme_1/workspace/SlimPajama-627B
# source_path=/scratch1_nvme_1/workspace/SlimPajama-627B
# target_path=/scratch1_nvme_2/workspace/slim_star_gutenberg_openwebmath_combined
source_path=/mnt/data/llm_datasets/SlimPajama-627B
# target_path=/scratch1_nvme_2/workspace/slim_star_gutenberg_openwebmath_combined
target_path=/mnt/data/llm_datasets/slim_validation_processed
#train: 26403 secs, 1.2T
tokenizer_path=./tokenizer
python3 prepare_slimpajama.py \
    --source_path $source_path \
    --tokenizer_path $tokenizer_path  \
    --destination_path $target_path \
    --split validation \
    --percentage 1.0
