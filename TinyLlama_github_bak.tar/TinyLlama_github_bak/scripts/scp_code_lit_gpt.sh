#sudo scp -r -i ~/id_rsa /mnt/data/amd/TinyLlama_github/* root@10.216.114.135:/mnt/data/amd/TinyLlama_github
sudo scp -r -i /home/amd/id_rsa /mnt/data/amd/TinyLlama_github/lit_gpt root@1.1.134.65:/mnt/data/amd/TinyLlama_github/
sudo scp -r -i /home/amd/id_rsa /mnt/data/amd/TinyLlama_github/lit_gpt root@1.1.133.65:/mnt/data/amd/TinyLlama_github/
sudo scp -r -i /home/amd/id_rsa /mnt/data/amd/TinyLlama_github/lit_gpt root@1.1.132.65:/mnt/data/amd/TinyLlama_github
sudo scp -r -i /home/amd/id_rsa /mnt/data/amd/TinyLlama_github/lit_gpt root@1.1.131.65:/mnt/data/amd/TinyLlama_github
sudo scp -r -i /home/amd/id_rsa /mnt/data/amd/TinyLlama_github/lit_gpt root@1.1.130.65:/mnt/data/amd/TinyLlama_github
sudo scp -r -i /home/amd/id_rsa /mnt/data/amd/TinyLlama_github/lit_gpt root@1.1.129.65:/mnt/data/amd/TinyLlama_github
sudo scp -r -i /home/amd/id_rsa /mnt/data/amd/TinyLlama_github/lit_gpt root@1.1.122.65:/mnt/data/amd/TinyLlama_github 
