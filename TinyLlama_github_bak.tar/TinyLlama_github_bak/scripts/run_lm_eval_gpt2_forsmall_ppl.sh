cp ./modeling_llama_origin.py /opt/conda/envs/py_3.10/lib/python3.10/site-packages/transformers/models/llama/modeling_llama.py
cp ./evaluator_origin.py /opt/conda/envs/py_3.10/lib/python3.10/site-packages/lm_eval/evaluator.py 
export HF_DATASETS_CACHE="./huggingface_data"
export CUDA_VISIBLE_DEVICES="4"
lm_eval --model hf \
    --model_args pretrained=../gpt2-large \
    --tasks wikitext\
    --device cuda:0 \
    --batch_size 1

    # --tasks winogrande,piqa,sciq,wsc,mmlu \
    # --model_args pretrained=../pythia-410m \
