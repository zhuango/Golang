net_card    = 'enp33s0f0np0'
main_addr   = "10.216.114.135"
main_port   = 23333
num_gpu_pn  = 2
num_node    = 2
gpu_ids     = '0,1'
dtype       = 'bf16-mixed'
data_path   = './slim_star_combined'
resume      = True

for i in range(num_node):
    script_format = f'export DATA_PATH={data_path}\n\
export CUDA_VISIBLE_DEVICES=\'{gpu_ids}\'\n\
export NCCL_SOCKET_IFNAME={net_card}\n\n\
lightning run model \\\n\
    --node-rank={i}  \\\n\
    --main-address={main_addr} \\\n\
    --accelerator=cuda \\\n\
    --devices={num_gpu_pn} \\\n\
    --num-nodes={num_node} \\\n\
    --main-port={main_port} \\\n\
    pretrain/tinyllama.py --precision \'{dtype}\' --devices {num_gpu_pn} --train_data_dir $DATA_PATH  --val_data_dir $DATA_PATH\
'
    if resume:
        script_format += ' --resume True'
    with open(f'./cluster/resume_train_node_{i}.sh', 'w') as f:
        f.write(script_format)
