#!/bin/bash

# 定义模型列表
models="gpt2 gpt2-large gpt2-medium gpt2-xl"

# 定义任务列表
tasks="winogrande,piqa,sciq,wsc,arc_easy,arc_challenge,logiqa,mmlu"

# 设置环境变量
export HF_DATASETS_CACHE="./huggingface_data"
export CUDA_VISIBLE_DEVICES="6"

# 循环评估不同的模型
for model in $models; do
    echo "Evaluating model: $model"
    
    # 拷贝模型文件
    # cp "./modeling_${model}_origin.py" "/opt/conda/envs/py_3.10/lib/python3.10/site-packages/transformers/models/llama/modeling_llama.py"
    
    # 使用 lm_eval 评估模型
    lm_eval --model hf \
        --model_args "pretrained=../$model" \
        --tasks "$tasks" \
        --device "cuda:0" \
        --batch_size 1

    echo "Finished evaluating $model"
done

echo "Script completed"

