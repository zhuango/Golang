#xcdlgpu03:/scratch1_nvme_1/workspace/starcoderdata
# source_path=/scratch1_nvme_1/workspace/starcoderdata
# target_path=/scratch1_nvme_2/workspace/slim_star_gutenberg_openwebmath_combined
# target_path=/scratch1_nvme_2/workspace/starcoder_test

source_path=/mnt/data/llm_datasets/starcoderdata/
target_path=/mnt/data/llm_datasets/starcoderdata_processed/
#train: 12549 secs, ~500G
tokenizer_path=./tokenizer

python prepare_starcoder.py \
    --source_path $source_path \
    --tokenizer_path $tokenizer_path  \
    --destination_path $target_path \
    --split train \
    --percentage 1.0
