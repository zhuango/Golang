cp ./modeling_llama_origin.py /opt/conda/envs/py_3.10/lib/python3.10/site-packages/transformers/models/llama/modeling_llama.py
cp ./evaluator_origin.py /opt/conda/envs/py_3.10/lib/python3.10/site-packages/lm_eval/evaluator.py
cp lm_eval_huggingface.py.origin /opt/conda/envs/py_3.10/lib/python3.10/site-packages/lm_eval/models/huggingface.py
cp lm_eval_utils_origin.py /opt/conda/envs/py_3.10/lib/python3.10/site-packages/lm_eval/utils.py
export HF_DATASETS_CACHE="./huggingface_data"
export CUDA_VISIBLE_DEVICES="7"
lm_eval --model hf \
    --model_args pretrained=../../TinyLlama-1.1B-intermediate-step-480k-1T \
    --tasks mmlu \
    --device cuda:0 \
    --batch_size 1

    # --tasks winogrande,piqa,sciq,wsc,mmlu \
    # ../TinyLlama-1.1B-intermediate-step-480k-1T
    # ../TinyLlama-1.1B-intermediate-step-1431k-3T
