net_card    = 'enp33s0f0np0'
main_addr   = "10.216.114.135"
main_port   = 23333
num_gpu_pn  = 8
num_node    = 8
gpu_ids     = '0,1,2,3,4,5,6,7'
dtype       = 'bf16-mixed'
train_data_path   = '/mnt/data/llm_datasets/slim_star_gutenberg_openwebmath_combined'
valid_data_path   = '/mnt/data/llm_datasets/slim_validation_processed'
resume      = True

for i in range(num_node):
    script_format = f'export TRAIN_DATA_PATH={train_data_path}\n\
export VALID_DATA_PATH={valid_data_path}\n\
export CUDA_VISIBLE_DEVICES=\'{gpu_ids}\'\n\
export NCCL_SOCKET_IFNAME={net_card}\n\n\
lightning run model \\\n\
    --node-rank={i}  \\\n\
    --main-address={main_addr} \\\n\
    --accelerator=cuda \\\n\
    --devices={num_gpu_pn} \\\n\
    --num-nodes={num_node} \\\n\
    --main-port={main_port} \\\n\
    pretrain/tinyllama_mup.py --precision \'{dtype}\' --devices {num_gpu_pn} --train_data_dir $TRAIN_DATA_PATH  --val_data_dir $VALID_DATA_PATH\\\n\
    --learning_rate 1e-3 \\\n\
    --lr_schedule  "cosine" \\\n\
    --initializer_range 0.01 \\\n\
'
    if resume:
        script_format += '    --resume True'
    with open(f'./cluster/resume_train_node_{i}_mup.sh', 'w') as f:
        f.write(script_format)
