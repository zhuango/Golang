#xcdlgpu03:/scratch1_nvme_1/workspace/open-web-math
# source_path=/scratch1_nvme_1/workspace/open-web-math
# target_path=/scratch1_nvme_2/workspace/slim_star_gutenberg_openwebmath_combined
# target_path=/scratch1_nvme_2/workspace/openwebmath_test
source_path=/mnt/data/llm_datasets/open-web-math/
target_path=/mnt/data/llm_datasets/open-web-math_processed
#train: 2141 secs, ~30G
tokenizer_path=./tokenizer

python prepare_openwebmath.py \
    --source_path $source_path \
    --tokenizer_path $tokenizer_path  \
    --destination_path $target_path \
    --split train \
    --percentage 1.0
