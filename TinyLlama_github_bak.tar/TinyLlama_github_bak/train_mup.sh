#export DATA_PATH=./slim_star_combined
export TRAIN_DATA_PATH=/mnt/data/llm_datasets/slim_star_gutenberg_openwebmath_combined
#export VALID_DATA_PATH=/mnt/data/llm_datasets/slim_validation_processed
export VALID_DATA_PATH=/mnt/data/wikitext2-raw_processed/
export CUDA_VISIBLE_DEVICES="4"

lightning run model \
    --node-rank=0  \
    --main-address=localhost \
    --accelerator=cuda \
    --num-nodes=1 \
    --devices=1 \
    scripts/eval.py \
    --precision 'bf16-mixed' \
    --train_data_dir $TRAIN_DATA_PATH  \
    --val_data_dir $VALID_DATA_PATH \
    --learning_rate 1e-3 \
    --lr_schedule  "cosine" \
    --initializer_range 0.01 \
    --resume True
    # --optimizer 'AdamW' \
