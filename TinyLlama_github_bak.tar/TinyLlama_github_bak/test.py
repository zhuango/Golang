from mup import MuReadout, make_base_shapes, set_base_shapes
from lit_gpt.model import GPT
from lit_gpt.model import Config
from transformers import AutoModelForCausalLM, AutoTokenizer
import torch

lm_model = AutoModelForCausalLM.from_pretrained('out_bak_iter_260000')
lm_model_base = AutoModelForCausalLM.from_pretrained('tiny_llama_base')
lm_model_delta = AutoModelForCausalLM.from_pretrained('tiny_llama_delta')

set_base_shapes(lm_model, lm_model_base, delta=lm_model_delta)
lm_model = lm_model

model_name = 'tiny_LLaMA_450M' # model to train
base_model_name = "tiny_LLaMA_base"  # smallest model
delta_model_name = "tiny_LLaMA_delta" # a model vary from base model, just for initialization
config = Config.from_name(model_name)
base_config = Config.from_name(base_model_name)
delta_config = Config.from_name(delta_model_name)
model = GPT(config)
base_model = GPT(base_config)
delta_model = GPT(delta_config)
w =torch.load('./out/tinyllama_mup_450M/iter-260000-ckpt.pth')
model.load_state_dict(w['model'])

set_base_shapes(model, base_model, delta=delta_model)
out = model(torch.arange(0,1024).unsqueeze(0))
out2 = lm_model(torch.arange(0,1024).unsqueeze(0))['logits']
print("EEEEEEEEEEEEEERROR: ", torch.sum(torch.abs(out-out2)))

