tar -xf flash-attention.tar
cd flash-attention
python setup.py install