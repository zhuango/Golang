from mup import MuReadout, make_base_shapes, set_base_shapes
from lit_gpt.model import GPT
from lit_gpt.model import Config
import torch

import transformers
from transformers import AutoModelForCausalLM, AutoTokenizer, StoppingCriteria, StoppingCriteriaList
import torch
import argparse
import json
#transformers.set_seed(1234)
#torch.manual_seed(1234)

class StopOnTokens(StoppingCriteria):
    def __init__(self, eos_token_id) -> None:
        self.eos_token_id = eos_token_id

    def __call__(self, input_ids: torch.LongTensor, scores: torch.FloatTensor, **kwargs) -> bool:
        stop_ids = [self.eos_token_id, 1, 0,2]
        for stop_id in stop_ids:
            if input_ids[0][-1] == stop_id:
                return True
        return False

model_path='out_bak_100m_iter_190000'
# model_path='../../pythia-160m/'
tokenizer_wargs = {'add_bos_token': False}
tokenizer = AutoTokenizer.from_pretrained(model_path, **tokenizer_wargs)
lm_model = AutoModelForCausalLM.from_pretrained(model_path)
model = lm_model.cuda().eval()

code_prompt =''#'You are a helpful, respectful and honest assistant. Always answer as helpfully as possible, while being safe.  Your answers should not include any harmful, unethical, racist, sexist, toxic, dangerous, or illegal content. '
# code_prompt += 'A is in hospital, B is in school. Where is A? '
code_prompt += '"Why?" "I would have thought you’d find him rather dry," she said. "I don’t know about that," said Gabriel. "He was a great craftsman," said Heather. "That he was," said Flannery. "And Polish, to boot," said'

input_ids = tokenizer(code_prompt, return_tensors="pt").input_ids
input_ids = input_ids.cuda()
print('========================')
print(code_prompt)
print(input_ids)
print('========================')
input_len = len(input_ids[0])

generated_ids = model.generate(input_ids,
    do_sample=False,
    repetition_penalty=1.0,
    temperature=1.0,
    top_p=0.95,
    max_new_tokens=100,
    stopping_criteria=StoppingCriteriaList([StopOnTokens(tokenizer.eos_token_id)]),
    use_cache=True)

output = tokenizer.decode(generated_ids[0], skip_special_tokens=False)
print(output)

